


document.getElementById('loginForm').addEventListener('submit', function(event) {
    event.preventDefault();
    
    var username = document.getElementById('email').value;
    var password = document.getElementById('password').value;

    var data = {
        username: username,
        password: password
    };

    fetch('https://fjjjwc4u88.execute-api.us-east-1.amazonaws.com/prod/login', {
        method: 'POST',
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(data)
    })
    .then(response => response.json())
    .then(data => {
        if (data.message === "Login successful") {
            console.log('Access token:', data.accessToken);
            localStorage.setItem('accessToken', data.accessToken);
            alert('Login successful!');
            window.location.href = 'search.html';
        } else {
            throw new Error('Authentication failed: ' + data.message);
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('Login failed: ' + error.message);
    });
});

function searchUsers() {
    // Implement search logic here
    alert('Search logic to be implemented');
}

function sendMoney() {
    const receiverId = document.getElementById('receiverId').value;
    const amount = document.getElementById('amount').value;

    fetch('https://fjjjwc4u88.execute-api.us-east-1.amazonaws.com/prod/sendmoney', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({
            receiverId: receiverId,
            amount: amount
        })
    })
    .then(response => response.json())
    .then(data => alert('Transaction Successful: ' + data.message))
    .catch(error => console.error('Error:', error));
}

function requestMoney() {
    // Implement request money logic here
    alert('Request money logic to be implemented');
}